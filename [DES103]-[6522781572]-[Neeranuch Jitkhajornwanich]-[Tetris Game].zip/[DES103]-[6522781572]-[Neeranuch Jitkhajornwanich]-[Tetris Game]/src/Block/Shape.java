package Block;
public class Shape {

    final int square [][] = {{1,1},
                                    {1,1}};

    final int line [][] = {{1,1,1,1}};

    final int left_l [][] = {{1,0,0},
                                    {1,1,1}};

    final int right_l [][] = {{0,0,1},
                                     {1,1,1}};

    final int left_s [][] = {{1,1,0},
                                    {0,1,1}};

    final int right_s [][] = {{0,1,1},
                                     {1,1,0}};

    final int t [][] = {{0,1,0},
                               {1,1,1}};
    
}
